
let a = Number(prompt("Adjon meg az osztandót"));
let b = Number(prompt("Adjon meg az osztót"));

if(a%b==0){
document.write("Osztható")
}
else{
document.write("Nem osztható")
}


