document.write("Rubint Márton<br>");
document.write("Team 13<br>");
document.write("HTML:100<br>");
document.write("CSS:100<br>");
document.write("JS:25<br>");


