
let a=Number(prompt("Adjon meg egy számot"));
let b=Number(prompt("Adja meg a mekkora hatványra szeretné emelni a számot"));

if(a>=0){
let x1=a**b;
document.write(`${a} a(z) ${b}-ik hatványom eredménye ${x1}`);
}



