
let range = Number(prompt("Adjon meg egy tetszőleges számot"));
let number = Math.floor( Math.random() * range / 2 ) * 2;

document.write(number)


